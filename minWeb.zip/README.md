# mint

> mintaWeb

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# 正式环境
npm run build:prod

#测试环境
npm run build:test

#预发布环境
npm run build:sim


For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
