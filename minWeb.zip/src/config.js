

window.minWebConfig={
    serverDomin:'https://app.wesetup.cn/', //服务的域名
    qiniuImgUrl:'https://img.wesetup.cn/', //七牛图片镜像路径前缀
    currentDomin:'www.shejiin.net/' //当前域名
}
