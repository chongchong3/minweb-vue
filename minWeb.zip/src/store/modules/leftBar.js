const leftBar = {
    state: {
      nav: {},
    },
  
    mutations: {
      setNav: (state, json) => {
        state.nav = json;
        
      },
  
    },
  

  };
  
  export default leftBar;