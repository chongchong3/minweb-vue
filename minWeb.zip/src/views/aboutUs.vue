<template>
	<div>
		
	
	<left-nav></left-nav>
		<head-nav></head-nav>
	<div class="aboutus-c">
		
		<div class="head-c">
			<h1 class="aboutus-title">关于设计IN
				<div class="title-bg"></div>
			</h1>
			<hr class="underline"></hr>
			
		</div>
		<section>
			<h2>
				设计IN是谁？
			</h2>
			<article class="art01">
				设计IN正式成立于2017年，专注为业主挑选专业、靠谱的设计师。创始人邢积国先生在家居界深耕近20年，于2015年1月启动平台筹备，整整两年时间，跟踪10000+案例，深度回访上千名装修业主，层层筛选出一批专业、靠谱的设计师。设计IN这一设计师严选平台的成立，将通过建立一系列行业标准，以保证设计服务的完美落地。
			</article>
			<div class="aboutus-arrow">
				ABOUT US
			</div>
			<img src="../../static/images/aboutus01.jpg" />
			<h2 class="strict">
				业内最严格的筛选标准
			</h2>
			<article class="art01">
				设计IN秉承业内最严苛的标准，5大严选维度，只为1个靠谱的结果。通过从设计师圈层口碑、专业能力、合作信用、从业经历、客户满意度等多个层面，以深度面访+专业评审+圈层调研，结合平台信用保障机制，为你挑选出真正专业、靠谱的设计师。
			</article>
		</section>
		<section class="service-section">
			<div class="aboutus-arrow">
				ABOUT US
			</div>
			<img src="../../static/images/aboutus02.jpg" />
			<h3 class="service-title">
				设计IN 提供什么服务？
			</h3>
			<h4 class="strict-designer-title">严选设计师为你量身定制</h4>
			<article class="art02">
				通过10余年对客户案例跟踪，以最严苛的标准，五大维度评估，层层筛选真正靠谱的优秀设计师。
			</article>
			<hr class="dotted-line" />
			<h4 class="serive-sub-title">
				首创行业设计监理保障服务
			</h4>
			<p class="bg-black">资金安全托管</p>
			<p class="bg-none">
				以客户满意为宗旨，分阶段验收支付，平台担保和信誉保证金为你保驾护航
			</p>
			<p class="bg-black">第三方图纸审核</p>
			<p class="bg-none">
				第三方专业团队把关设计图纸，确保预算的合理性和设计方案的可落地性
			</p>
			<p class="bg-black">落地跟踪服务</p>
			<p class="bg-none">
				以终为始，围绕设计方案，设计实现度，客户满意度，全程跟踪监管设计后过程服务，确保设计效果的完美落地
			</p>
			<hr class="dotted-line" />
		</section>
		<section class="version-section">
			<div class="aboutus-arrow">
				ABOUT US
			</div>
			<img src="../../static/images/aboutus03.jpg" />
			<h2>
				设计IN的愿景
			</h2>
			<p>创建一个梦想家是一件人生大事</p>
			<p>越慎重也越容易莽撞懵懂，我们不想你历经坎坷后</p>
			<p>仍留有遗憾</p>
			<p>你只需把憧憬交给我们，和设计IN严选的设计师一起，把家装这件大事，变得幸福和简单。</p>
			<p>一个适合的设计师，就是梦想家实现的开始</p>
			<p>我们想要做的是</p>
			<p>让好的设计走进千家万户</p>
			<p class="text-left">让对生活有态度、对设计有追求、对家有梦想的你，在创建一个梦想家的过程中能找到一个真正懂你的设计师。</p>
			<hr class="dotted-line" />
		</section>
		<section class="contact-section">
			<h2>联系我们</h2>
			<p class="con-sub-title" style="margin-top:.22rem">商务合作</p>
			<p>联络邮箱：zhangyi@shejiin.com</p>
			<p>联络QQ：364134696</p>
			<p>*请简要注明合作品牌或项目，谢谢</p>
			<p class="con-sub-title">设计师招募</p>
			<p>联络邮箱：chenx@shejiin.com</p>
			<p class="con-sub-title">客服电话</p>
			<p>0571-86705859</p>
		</section>
		<section class="qrCode-section">
			<img src="../../static/images/qrcode.jpg" />
		</section>
	</div>
	</div>
</template>
<style scoped="scoped">
.aboutus-c {
  padding: 0 0.2rem;
  text-align: center;
}
.head-c {
  text-align: center;
}
.aboutus-title {
  margin: 0 auto;
  margin-top: 0.45rem;
  font-weight: bold;
  font-size: 0.17rem;
  line-height: 0.23rem;
  text-align: center;
  padding: 0;
  letter-spacing: 0.02rem;
  position: relative;
  width: 1rem;
  /*padding-bottom:0.2rem;*/
}
.title-bg {
  width: 0.95rem;
  height: 0.06rem;
  background: #fff999;
  position: absolute;
  opacity: 0.7;
  top: 0.09rem;
  left: 0.02rem;
}
.underline {
  width: 1rem;
  background-color: #636363;
  border: none;
  height: 1px;
  margin: 0 auto;
}
h2 {
  font-size: 0.14rem;
  line-height: 0.19rem;
  display: inline-block;
  background-color: #fff100;
  margin: 0 auto;
  letter-spacing: 0.01rem;
  margin-top: 0.35rem;
  margin-bottom: 0.2rem;
}
.art01 {
  font-size: 0.12rem;
  line-height: 0.2rem;
  text-align: justify;
  letter-spacing: 0.01rem;
  color: #636363;
}
.aboutus-arrow {
  margin: 0 auto;
  margin-top: 0.23rem;
  margin-bottom: 0.05rem;
  text-align: center;
  font-size: 0.12rem;
  position: relative;
  width: 1rem;
  color: #636363;
}
.aboutus-arrow:after {
  position: absolute;
  right: -0.05rem;
  top: -0.05rem;
  content: "";
  background: url(../../static/images/wui-spirite.png) 0px 0.02rem no-repeat;
  width: 0.2rem;
  height: 0.2rem;
  display: block;
}
img {
  width: 100%;
}
.service-title {
  font-size: 0.13rem;
  line-height: 0.23rem;
  margin: 0.46rem 0 0.26rem;
  text-align: center;
}
.strict-designer-title {
  position: relative;
  text-align: left;
  text-indent: 0.3rem;
  margin: 0;
  font-size: 0.12rem;
  letter-spacing: 0.01rem;
  margin-bottom: 0.08rem;
}
.strict-designer-title:before {
  position: absolute;
  left: 0rem;
  top: -0.05rem;
  content: "";
  background: url(../../static/images/wui-spirite.png) 0px -0.35rem no-repeat;
  display: block;
  background-size: 100%;
  width: 0.27rem;
  height: 0.2rem;
}
.art02 {
  font-size: 0.12rem;
  line-height: 0.2rem;
  text-align: justify;
  letter-spacing: 0.01rem;
  margin-bottom: 0.15rem;
  color: #636363;
}
.dotted-line {
  width: 100%;
  height: 2px;
  border: none;
  background: url(../../static/images/split-line.png) repeat-x;
}
.serive-sub-title {
  text-align: right;
  font-weight: 500;
  position: relative;
  margin-top: 0.38rem;
}
.serive-sub-title:before {
  position: absolute;
  right: 1.4rem;
  top: -0.04rem;
  content: "";
  background: url(../../static/images/wui-spirite.png) 0px -0.15rem no-repeat;
  background-size: 100%;
  width: 0.27rem;
  height: 0.2rem;
  display: block;
}
.service-section {
  text-align: right;
}
p {
  margin: 0;
}
p.bg-black {
  background-color: #000;
  color: #fff;
  display: inline-block;
  font-size: 0.12rem;
  line-height: 0.18rem;
  margin-bottom: 0.07rem;
}
p.bg-none {
  color: #636363;
  display: inline-block;
  font-size: 0.12rem;
  line-height: 0.18rem;
  margin-bottom: 0.09rem;
}
.version-section {
  text-align: center;
}
.version-section p {
  display: block;
  line-height: 0.19rem;
  font-size: 0.12rem;
}
.version-section p.text-left {
  text-align: left;
  margin-bottom: 0.23rem;
}
.contact-section {
  color: #636363;
  text-align: center;
  font-size: 0.12rem;
  line-height: 0.2rem;
}
.contact-section h2 {
  background: none;
  font-size: 0.15rem;
  margin-bottom: 0;
  margin-top: 0.3rem;
}
.contact-section .con-sub-title {
  margin-bottom: 0.11rem;
  margin-top: 0.29rem;
}
.contact-section p {
  margin-bottom: 0.07rem;
}
.contact-section p:last-child {
  margin-bottom: 0.34rem;
}
.qrCode-section {
}
.qrCode-section img {
  width: 100%;
  margin-bottom: 0.5rem;
  /*border:.02rem solid #000;*/
}
</style>
<script>

import leftNav from "../components/leftNav"; //引用左侧菜单栏
import headNav from "../components/headNav"; //引用顶部菜单栏
export default {
  components: {
    leftNav,
    headNav
  },
  data() {
    return {};
  },
  created() {
     this.shareWx.getId();
    this.shareWx.shareReady("关于 | 设计IN-设计师严选平台");
    this.$store.commit("setNav", {
      isShow: false, //左侧菜单栏默认为关闭状态
      current: "aboutUs" //设置左菜单栏高亮
    });
  }
};

</script>