'use strict'
module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"test"', //发布环境 
  BASE_API: '"www.shejiin.dev/"',//接口api
  SHARE_API: '"app.shejiin.dev/"', //分享接口
  QINIU_IMG:'"https://img.wesetup.cn/"'//七牛图片
};

