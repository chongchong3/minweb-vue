module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"', //发布环境 
  BASE_API: '"https://www.shejiin.dev/"',//接口api
  SHARE_API: '"https://app.shejiin.dev/"', //分享接口
  QINIU_IMG:'"https://img.wesetup.cn/"'//七牛图片
}
